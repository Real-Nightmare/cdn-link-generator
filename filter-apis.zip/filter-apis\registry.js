const path = require('path');
const { LightspeedClient } = require('./lightspeed');

function asText(x) {
  if (x == null) return '';
  if (Array.isArray(x)) return String(x[0] ?? '');
  if (typeof x === 'object') return String(x.category ?? x.name ?? '');
  return String(x);
}
const isErr = x => x === 'Error' || x == null;

// Sophos + Barracuda ship no block list, and gn-math blocks anything that isn't
// clearly work/school-safe. Allow-list instead: only these pass.
const SOPHOS_ALLOWED_PROD = new Set([
  0,  // UNCATEGORIZED
  6,  // GENERAL_BUSINESS
  7,  // BUSINESS_CLOUD_APPS
  8,  // BUSINESS_NETWORKING
  10, // CONTENT_DELIVERY
  13, // CRL_AND_OCSP
  16, // EDUCATIONAL_INSTITUTIONS
  20, // FINANCIAL_SERVICES
  23, // GOVERNMENT
  25, // HEALTH_AND_MEDICINES
  29, // INFORMATION_TECHNOLOGY
  39, // MILITARY
  41, // NEWS
  42, // NGOS_AND_NON_PROFITS
  55, // POLITICAL_ORGANIZATION
  57, // PROFESSIONAL_AND_WORKERS_ORGANIZATIONS
  61, // REFERENCE
  62, // RELIGION_AND_SPIRITUALITY
  64, // SEARCH_ENGINES
  68, // SOFTWARE_UPDATES
]);
const BARRACUDA_ALLOWED = [
  'content server', 'business', 'information technology', 'computers and technology', 'technology',
  'education', 'search engines', 'search engines and portals', 'portal', 'news', 'news and media',
  'government', 'health', 'medicine', 'finance', 'financial', 'reference', 'translation',
  'content delivery', 'web hosting', 'internet services', 'general', 'uncategorized', 'unknown',
];

let _ls = null;
const lsClient = () => (_ls = _ls || new LightspeedClient());

function makeGate(maxConcurrent, minIntervalMs = 0) {
  let active = 0;
  let lastStart = 0;
  const waiters = [];
  const pump = () => {
    if (active >= maxConcurrent || !waiters.length) return;
    const wait = Math.max(0, lastStart + minIntervalMs - Date.now());
    const next = waiters.shift();
    active++;
    lastStart = Date.now() + wait;
    setTimeout(next, wait);
  };
  return fn => (...args) =>
    new Promise((resolve, reject) => {
      waiters.push(() => {
        Promise.resolve()
          .then(() => fn(...args))
          .then(resolve, reject)
          .finally(() => {
            active--;
            pump();
          });
      });
      pump();
    });
}

// Talos rate-limits hard; keep Cisco slow. Others are fine wide-open.
const ciscoGate = makeGate(2, 600);

// Accept a bare domain OR a full URL with path/query. Each adapter takes the
// form its endpoint supports: `full` (scheme + path), `hostPath` (no scheme),
// or `host` (domain only, for APIs that can't see paths).
function target(input) {
  let s = String(input || '').trim();
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = 'http://' + s;
  let u = null;
  try {
    u = new URL(s);
  } catch {}
  const host = (u ? u.hostname : String(input).trim()).toLowerCase().replace(/^www\./, '');
  const full = u ? u.toString() : `http://${host}/`;
  const hostPath = full.replace(/^https?:\/\//i, '');
  return { host, full, hostPath };
}

const ALL_FILTERS = [
  {
    name: 'Lightspeed', // host-only endpoint
    async run(input) {
      const v = await lsClient().lookup(target(input).host);
      return { category: v.category, blocked: v.blocked };
    },
  },
  {
    name: 'FortiGuard',
    async run(input) {
      const r = await require('./vendor/fortiguard').fortiguard(target(input).full);
      if (isErr(r)) throw new Error('fortiguard error');
      return { category: r.category, blocked: !!r.blocked };
    },
  },
  {
    name: 'Palo Alto',
    async run(input) {
      const r = await require('./vendor/paloalto').palo(target(input).full);
      if (isErr(r)) throw new Error('palo error');
      return { category: asText(r), blocked: r[1] === false };
    },
  },
  {
    name: 'Blocksi Web',
    async run(input) {
      const r = await require('./vendor/blocksi').blocksiStandard(target(input).full);
      if (isErr(r)) throw new Error('blocksi web error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'Blocksi AI',
    async run(input) {
      const r = await require('./vendor/blocksi').blocksiAI(target(input).full);
      if (isErr(r)) throw new Error('blocksi ai error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'Linewize',
    async run(input) {
      const r = await require('./vendor/linewize').linewize(target(input).full);
      if (isErr(r)) throw new Error('linewize error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'Cisco Umbrella',
    slow: true,
    run: ciscoGate(async input => {
      const r = await require('./vendor/cisco').cisco(target(input).full);
      if (isErr(r)) throw new Error('cisco error');
      return { category: asText(r), blocked: !!r[1] };
    }),
  },
  {
    name: 'Securly',
    async run(input) {
      const r = await require('./vendor/securly').securly(target(input).full);
      if (isErr(r)) throw new Error('securly error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'GoGuardian',
    async run(input) {
      const r = await require('./vendor/goguardian').goguardian(target(input).full);
      if (isErr(r)) throw new Error('goguardian error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'LanSchool',
    async run(input) {
      const r = await require('./vendor/lanschool').lanschool(target(input).hostPath);
      if (isErr(r)) throw new Error('lanschool error');
      const blocked = r !== 'LanSchool' && r !== 'Error' && r != null && r !== '';
      return { category: blocked ? asText(r) : 'LanSchool', blocked };
    },
  },
  {
    name: 'ContentKeeper',
    async run(input) {
      const r = await require('./vendor/contentkeeper').contentkeeper(target(input).full);
      if (isErr(r)) throw new Error('contentkeeper error');
      return { category: r.category, blocked: !!r.blocked };
    },
  },
  {
    name: 'AristotleK12',
    async run(input) {
      const r = await require('./vendor/aristotle').aristotlek12(target(input).full);
      if (isErr(r)) throw new Error('aristotle error');
      return { category: asText(r), blocked: !!r.blocked };
    },
  },
  {
    name: 'Senso Cloud',
    async run(input) {
      const r = await require('./vendor/senso').sensocloud(target(input).hostPath);
      if (isErr(r)) throw new Error('senso error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'Deledao', // domain-categorization API; path adds nothing reliable
    async run(input) {
      const r = await require('./vendor/deledao').deledao(target(input).host);
      if (isErr(r)) throw new Error('deledao error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'iBoss',
    async run(input) {
      const r = await require('./vendor/iboss').iboss(target(input).full);
      if (isErr(r)) throw new Error('iboss error');
      return { category: asText(r), blocked: !!r[1] };
    },
  },
  {
    name: 'Sophos',
    async run(input) {
      const r = await require('./vendor/sophos').sophos(target(input).full);
      if (isErr(r)) throw new Error('sophos error');
      if (!r.found) return { category: 'Uncategorized', blocked: false };
      const blocked =
        !!r.isThreat || r.riskLevelNum >= 4 || !SOPHOS_ALLOWED_PROD.has(r.productivityCategoryNum);
      return { category: r.productivityCategory + (r.isThreat ? ` / ${r.threat}` : ''), blocked };
    },
  },
  {
    name: 'Barracuda', // domain-level reputation only
    async run(input) {
      const r = await require('./vendor/barracuda').barracuda(target(input).host);
      if (isErr(r)) throw new Error('barracuda error');
      const cat = String(r);
      const cl = cat.toLowerCase();
      const blocked = !BARRACUDA_ALLOWED.some(a => cl.includes(a));
      return { category: cat, blocked };
    },
  },
];

// endpoints/creds that were shared publicly and have since rotated or locked —
// leave off until someone sources a fresh one. gn-math `check` still covers these.
const DISABLED = new Set([
  'GoGuardian', 'Securly', 'Palo Alto', 'LanSchool', 'iBoss', 'ContentKeeper',
  // Talos rate-limits ("You've reached the limit") far too aggressively for a bulk
  // sweep even at 1-2 rps; not viable direct. Stays on gn-math.
  'Cisco Umbrella',
]);

const FILTERS = ALL_FILTERS.filter(f => !DISABLED.has(f.name));

function closeAll() {
  if (_ls) {
    _ls.close();
    _ls = null;
  }
}

module.exports = { FILTERS, ALL_FILTERS, DISABLED, closeAll };
