const WebSocket = require('ws');
const path = require('path');
const fs = require('fs');

const WS_URL =
  'wss://production-gc.lsfilter.com?a=0ef9b862-b74f-4e8d-8aad-be549c5f452a&customer_id=74-1082-F000&agentType=chrome_extension&agentVersion=3.777.0&userGuid=00000000-0000-0000-0000-000000000000';
const CUSTOMER_ID = '74-1082-F000';
const LOOKUP_IP = '174.85.104.135';

const CATS = JSON.parse(fs.readFileSync(path.join(__dirname, 'lightspeed-categories.json'), 'utf8'));
const CAT_BY_NUM = new Map(CATS.map(c => [Number(c.CategoryNumber), c]));

function categoryOf(num) {
  const c = CAT_BY_NUM.get(Number(num));
  if (!c) return { catNum: num, category: `cat ${num}`, allow: null, blocked: null };
  const allow = String(c.Allow) === '1';
  return { catNum: Number(num), category: c.CategoryName, allow, blocked: !allow };
}

class LightspeedClient {
  constructor({ timeoutMs = 12000 } = {}) {
    this.timeoutMs = timeoutMs;
    this.ws = null;
    this.ready = null;
    this.pending = new Map();
    this.closed = false;
  }

  _connect() {
    if (this.ready) return this.ready;
    this.ready = new Promise((resolve, reject) => {
      const ws = new WebSocket(WS_URL);
      this.ws = ws;
      ws.on('open', () => resolve(ws));
      ws.on('message', raw => {
        let j;
        try {
          j = JSON.parse(raw.toString());
        } catch {
          return;
        }
        const host = j && j.request && j.request.host;
        if (!host || !this.pending.has(host)) return;
        const waiters = this.pending.get(host);
        this.pending.delete(host);
        for (const w of waiters) {
          clearTimeout(w.timer);
          w.resolve(categoryOf(j.cat));
        }
      });
      const drop = err => {
        this.ready = null;
        this.ws = null;
        const e = err || new Error('lightspeed socket closed');
        for (const [, waiters] of this.pending) for (const w of waiters) {
          clearTimeout(w.timer);
          w.reject(e);
        }
        this.pending.clear();
        reject(e);
      };
      ws.on('error', drop);
      ws.on('close', () => drop());
    });
    return this.ready;
  }

  // A timed-out lookup almost always means the socket has gone silently dead
  // (no close/error frame, just stopped replying) -- reusing it forever would
  // mean every lookup times out until the whole bot process restarts. Kill it
  // so the next call reconnects fresh instead.
  _forceReset() {
    const dead = this.ws;
    this.ready = null;
    this.ws = null;
    try { dead && dead.terminate(); } catch {}
  }

  async lookup(host) {
    if (this.closed) throw new Error('client closed');
    host = String(host).toLowerCase().replace(/^www\./, '').replace(/^https?:\/\//, '').split('/')[0];
    let ws;
    try {
      ws = await this._connect();
    } catch (e) {
      ws = await this._connect();
    }
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        const waiters = this.pending.get(host);
        if (waiters) {
          const left = waiters.filter(w => w.timer !== timer);
          if (left.length) this.pending.set(host, left);
          else this.pending.delete(host);
        }
        if (this.ws === ws) this._forceReset();
        reject(new Error('lightspeed lookup timeout'));
      }, this.timeoutMs);
      const waiter = { resolve, reject, timer };
      if (this.pending.has(host)) this.pending.get(host).push(waiter);
      else this.pending.set(host, [waiter]);
      try {
        ws.send(JSON.stringify({ action: 'dy_lookup', host, ip: LOOKUP_IP, customerId: CUSTOMER_ID }));
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(host);
        reject(e);
      }
    });
  }

  close() {
    this.closed = true;
    try {
      this.ws && this.ws.close();
    } catch {}
  }
}

module.exports = { LightspeedClient, categoryOf };

if (require.main === module) {
  (async () => {
    const c = new LightspeedClient();
    for (const h of process.argv.slice(2).length ? process.argv.slice(2) : ['pornhub.com', 'example.com', 'coolmathgames.com']) {
      try {
        console.log(h, '->', JSON.stringify(await c.lookup(h)));
      } catch (e) {
        console.log(h, 'ERR', e.message);
      }
    }
    c.close();
  })();
}
