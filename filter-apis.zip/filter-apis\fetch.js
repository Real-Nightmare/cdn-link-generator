const { Agent, setGlobalDispatcher } = require('undici');

const insecure = new Agent({
  connect: { rejectUnauthorized: false, timeout: 15000 },
  headersTimeout: 20000,
  bodyTimeout: 20000,
});

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

async function fetchURL(url, opts = {}) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), opts.timeoutMs || 20000);
  try {
    return await fetch(url, {
      ...opts,
      dispatcher: insecure,
      signal: opts.signal || controller.signal,
      headers: { 'user-agent': UA, ...(opts.headers || {}) },
    });
  } finally {
    clearTimeout(timer);
  }
}

module.exports = { fetchURL, insecureDispatcher: insecure };
