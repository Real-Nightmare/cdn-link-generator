const fs = require('fs');
const path = require('path');

const FILE = path.join(__dirname, '..', '..', 'data', 'filters.json');

function read() {
  try {
    return JSON.parse(fs.readFileSync(FILE, 'utf8'));
  } catch {
    return {};
  }
}

function write(obj) {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  const tmp = `${FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(obj, null, 2));
  fs.renameSync(tmp, FILE);
}

// entries: [ [domain, { filterName: verdict, ... }], ... ] — merged per domain
function upsert(entries) {
  const cur = read();
  for (const [domain, filters] of entries) {
    cur[domain] = { ...(cur[domain] || {}), ...filters };
  }
  write(cur);
  return cur;
}

module.exports = { FILE, read, write, upsert };
